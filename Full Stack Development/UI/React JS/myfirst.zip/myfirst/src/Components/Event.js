import React from 'react'

function Event() {

    const shoot =()=>{
        alert('Great shot champ')
    }

    const kick = (a)=>{
        
        alert(a);
    }

  return (
    <div>
        <p>Simple Button</p>
      <button  onClick={shoot}>SHOOT</button>
      <p>Button With Argument</p>
      <button onClick={()=>kick("Goalllllll...")}>KICK</button>

    </div>
  )
}

export default Event
