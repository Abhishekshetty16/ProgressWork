import React from "react";

function Car(props) {
  return <li>I am a {props.brand}</li>;
}

function Lists() {
  const cars = [
    { id: 1, brand: "Ford" },
    { id: 2, brand: "BMW" },
    { id: 3, brand: "Audi" },
  ];
  return (
    <>
      <h2> LIST(map)</h2>

      <h4>Who lives in my garage?</h4>
      <ol>
        {cars.map((car) => (
          <Car key={car.id} brand={car.brand} />
        ))}
      </ol>
    </>
  );
}

export default Lists;
