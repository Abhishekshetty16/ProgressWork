import React from 'react'

function Cars(props) {
  return (
    <div>
      <h3>Simple Component</h3>
      <h3><i>Simple Prop :</i> I am a {props.brand}</h3>
    </div>
  )
}

export default Cars
