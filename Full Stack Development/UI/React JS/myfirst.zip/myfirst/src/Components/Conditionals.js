import React from "react";

function Conditionals(props) {
  const cars = props.cars;
  const status = props.status;

  return (
    <>
      <h2>Logical && Operator</h2>
      <h3> my Garage</h3>
      {cars.length > 0 && <h5>You have {cars.length} cars in your garage.</h5>}

      {status ? <p>Ternary Operator : true</p> : <p>Ternary Operator :false</p>}
    </>
  );
}

export default Conditionals;
