import "./App.css";
import Cars from "./Components/Compo&Props";
import Conditionals from "./Components/Conditionals";
import Event from "./Components/Event";
import Lists from "./Components/Lists";

function App() {
  const cars = ["Ford", "BMW", "Audi"];

  return (
    <>
      <div className="App">
        <h1>APP.JS</h1>
        <hr />
        <Cars brand="ford" />
        <hr />
        <Event />
        <hr />
        <Conditionals cars={cars} status={true} />
        <hr />
        <Lists />
      </div>
    </>
  );
}

export default App;
